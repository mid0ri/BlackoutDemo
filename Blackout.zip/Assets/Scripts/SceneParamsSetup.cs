﻿using UnityEngine;
using System.Collections;

public class SceneParamsSetup : MonoBehaviour {

	public HealthBarManager healthBarManager;

	void Start () {
		Debug.Log(PlayerPrefs.GetInt ("Player Health") + "Health");
		healthBarManager.SendMessage ("SetupScene", PlayerPrefs.GetInt ("Player Health"));
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
