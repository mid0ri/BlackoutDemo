﻿using UnityEngine;
using System.Collections;

public class HealthBarManager : MonoBehaviour {
	public GameObject[] hearts;
	public int numberOfHearts;


	private PlayerController thePlayer;

	void Start () {
		numberOfHearts = hearts.Length;
		thePlayer = GetComponent<PlayerController> ();


	}

	void OnCollisionEnter2D(Collision2D coll){
		if(coll.gameObject.tag == "Danger"){
			SendKnockBackMessage (coll.transform.position);
			numberOfHearts--;
			hearts [numberOfHearts].SetActive (false);
		}

		if (numberOfHearts == 0){
			thePlayer.SendMessage ("SetDeath", true);
			Reset ();
		}			
	}

	private void Reset(){
		numberOfHearts = hearts.Length;
		foreach(GameObject go in hearts)
			go.SetActive (true);		
	}

	private void SetupScene(int resumeNumberOfHearts){
		numberOfHearts = resumeNumberOfHearts;
		for(int i=0; i<hearts.Length; i++){
			if (i < resumeNumberOfHearts)
				hearts [i].SetActive (true);
			else
				hearts [i].SetActive (false);
		}
	}
	IEnumerator haltMovement(){
		thePlayer.movementEnabled = false;
		yield return new WaitForSeconds (1f);
		thePlayer.movementEnabled = true;
	}

	void SendKnockBackMessage(Vector3 hazardObjPos){
		StartCoroutine ("haltMovement"); 
		Vector3 heading = transform.position - hazardObjPos;
		heading /= (heading.magnitude);
		Vector2 directionConverted = new Vector2 (heading.x, heading.y);
		thePlayer.SendMessage ("RecieveKnockBackMessage", directionConverted);
	}

	public int getNumberOfActiveHearts(){
		return numberOfHearts;
	}
}
