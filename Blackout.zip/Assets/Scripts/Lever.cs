﻿using UnityEngine;
using System.Collections;

public class Lever : MonoBehaviour {

	Animator anim;
	public MovingPlatform platform;


	// Use this for initialization
	void Start () 
	{
		anim = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}

	void OnTriggerStay2D(Collider2D other)
	{
		if (Input.GetKeyDown (KeyCode.RightShift) && anim.GetBool ("flipDown") == false) 
			{
				anim.SetBool ("flipDown", true);
				platform.platformSpeed = platform.userSetSpeed;
			}
		else if (Input.GetKeyDown (KeyCode.RightShift) && anim.GetBool ("flipDown") == true) 
			{
				anim.SetBool ("flipDown", false);
				platform.platformSpeed = 0;
			}
	}

}
